# Lz Store

Reconstrução do marketplace usando HTML5, CSS3 e JavaScript puro no frontend, Node.js + Express no backend e SQLite no banco de dados.

## Requisitos
- Node.js 20 ou superior
- npm

## Como executar
1. Extraia a pasta.
2. Abra um terminal dentro de `Lz Store`.
3. Execute `npm install`.
4. Execute `npm run dev`.
5. Acesse http://localhost:3000.

O projeto começa com dados demonstrativos. Autenticação, pagamentos reais, upload de imagens e integrações externas ainda precisam ser implementados e configurados antes de uso em produção.

## Estrutura
- `public/`: arquivos enviados ao navegador (HTML, CSS, JavaScript e imagens).
- `server/`: aplicação Express, rotas, controladores, serviços e acesso ao banco.
- `database/`: schema e banco SQLite criado automaticamente.
- `docs/`: documentação técnica e roteiro de desenvolvimento.

## Próximas etapas
Consulte `docs/ROADMAP.md`. A página de assinaturas e os produtos iniciais são uma base demonstrativa, não uma cópia integral garantida do site publicado.

const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const productRoutes = require('./routes/product.routes');
const { initializeDatabase } = require('./config/database');

const app = express();
const PORT = process.env.PORT || 3000;

initializeDatabase();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use('/api/products', productRoutes);
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'Lz Store API' }));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.listen(PORT, () => console.log(`Lz Store disponível em http://localhost:${PORT}`));

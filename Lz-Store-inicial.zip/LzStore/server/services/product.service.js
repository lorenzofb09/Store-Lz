const { getDatabase } = require('../config/database');
function list(category) {
  if (category) return getDatabase().prepare('SELECT * FROM products WHERE active = 1 AND category = ? ORDER BY id DESC').all(category);
  return getDatabase().prepare('SELECT * FROM products WHERE active = 1 ORDER BY id DESC').all();
}
function getById(id) {
  if (!Number.isInteger(id) || id <= 0) return null;
  return getDatabase().prepare('SELECT * FROM products WHERE id = ? AND active = 1').get(id);
}
module.exports = { list, getById };

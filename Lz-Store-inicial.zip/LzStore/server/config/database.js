const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, '..', '..', 'database', 'lz-store.sqlite');
const schemaPath = path.join(__dirname, '..', '..', 'database', 'schema.sql');
let db;
function initializeDatabase() {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  db = new Database(dbPath);
  db.pragma('foreign_keys = ON');
  db.exec(fs.readFileSync(schemaPath, 'utf8'));
  const count = db.prepare('SELECT COUNT(*) AS total FROM products').get().total;
  if (count === 0) {
    const insert = db.prepare(`INSERT INTO products (name, description, category, category_label, segment, price_cents, symbol, active) VALUES (@name,@description,@category,@category_label,@segment,@price_cents,@symbol,1)`);
    const seed = db.transaction(items => items.forEach(item => insert.run(item)));
    seed([
      {name:'Plano Gamer Essencial',description:'Exemplo de assinatura para a categoria gamer.',category:'assinatura',category_label:'Assinatura',segment:'gaming',price_cents:2990,symbol:'🎮'},
      {name:'Plano Entretenimento',description:'Exemplo de serviço digital de entretenimento.',category:'assinatura',category_label:'Assinatura',segment:'entretenimento',price_cents:3990,symbol:'▶'},
      {name:'Aventura Digital',description:'Produto demonstrativo de jogo digital.',category:'jogo',category_label:'Jogo',segment:'gaming',price_cents:5990,symbol:'⚔'},
      {name:'Gift Card Digital',description:'Exemplo de cartão-presente digital.',category:'gift-card',category_label:'Gift card',segment:'gaming',price_cents:5000,symbol:'✦'}
    ]);
  }
}
function getDatabase() { if (!db) throw new Error('Banco de dados ainda não foi inicializado.'); return db; }
module.exports = { initializeDatabase, getDatabase };

const productService = require('../services/product.service');
function list(req, res, next) {
  try {
    const products = productService.list(req.query.category);
    res.json(products);
  } catch (error) { next(error); }
}
function getById(req, res, next) {
  try {
    const product = productService.getById(Number(req.params.id));
    if (!product) return res.status(404).json({ error: 'Produto não encontrado.' });
    res.json(product);
  } catch (error) { next(error); }
}
module.exports = { list, getById };

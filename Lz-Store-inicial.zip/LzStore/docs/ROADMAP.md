# Roteiro de desenvolvimento

- [x] Criar estrutura organizada de diretórios.
- [x] Montar página inicial responsiva inicial.
- [x] Criar página de assinaturas.
- [x] Criar páginas-base de login, cadastro, ajuda e termos.
- [x] Criar API de leitura de produtos.
- [x] Criar schema SQLite e dados demonstrativos.
- [ ] Comparar visualmente com todas as páginas públicas atuais do Lz Store.
- [ ] Ajustar identidade visual com logo, cores, tipografia e imagens oficiais.
- [ ] Criar páginas de listagem, detalhes e busca avançada.
- [ ] Implementar autenticação e autorização.
- [ ] Implementar área do comprador e do vendedor.
- [ ] Implementar carrinho, pedidos e checkout.
- [ ] Integrar pagamento real por provedor adequado (ambiente de testes primeiro).
- [ ] Implementar gestão de produtos e painel administrativo.
- [ ] Criar testes automatizados, acessibilidade e revisão de segurança.
- [ ] Preparar deploy, domínio, HTTPS, backups e monitoramento.

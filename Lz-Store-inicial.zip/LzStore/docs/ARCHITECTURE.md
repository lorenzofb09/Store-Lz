# Arquitetura inicial

## Fluxo
1. O navegador solicita uma página em `public/`.
2. O JavaScript da página consulta a API usando `fetch`.
3. A rota Express recebe a solicitação.
4. O controller valida e coordena a resposta.
5. O service consulta o SQLite.
6. A API devolve JSON ao navegador.

## Camadas
- `routes`: define os endereços HTTP.
- `controllers`: trata requisições e respostas.
- `services`: concentra regras e consultas.
- `config`: inicialização e conexão com recursos.
- `database/schema.sql`: estrutura inicial do banco.

## Segurança pendente antes de produção
Implementar hash de senhas (Argon2 ou bcrypt), sessões seguras, proteção CSRF conforme autenticação, validação de entrada, rate limiting, logs, política de privacidade, termos revisados e integração de pagamento por provedor homologado. Nunca guardar dados de cartão.

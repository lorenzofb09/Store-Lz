const grid = document.querySelector('#product-grid');
const filterRow = document.querySelector('#filter-row');
const searchForm = document.querySelector('#search-form');
const searchInput = document.querySelector('#search-input');

async function loadProducts() {
  if (!grid) return;
  try {
    const response = await fetch('/api/products');
    if (!response.ok) throw new Error('Não foi possível carregar os produtos.');
    const products = await response.json();
    renderProducts(products);
    filterRow?.addEventListener('click', event => {
      const button = event.target.closest('[data-filter]');
      if (!button) return;
      filterRow.querySelectorAll('.filter-chip').forEach(item => item.classList.remove('is-active'));
      button.classList.add('is-active');
      const category = button.dataset.filter;
      renderProducts(category === 'todos' ? products : products.filter(item => item.category === category));
    });
    searchForm?.addEventListener('submit', event => {
      event.preventDefault();
      const term = searchInput.value.trim().toLocaleLowerCase('pt-BR');
      renderProducts(products.filter(item => item.name.toLocaleLowerCase('pt-BR').includes(term)));
    });
  } catch (error) {
    grid.innerHTML = `<p class="muted">${error.message}</p>`;
  }
}
function renderProducts(products) {
  grid.innerHTML = products.length ? products.map(product => `
    <article class="product-card">
      <div class="product-art" aria-hidden="true">${escapeHtml(product.symbol || '🎮')}</div>
      <div class="product-info">
        <span class="product-type">${escapeHtml(product.category_label)}</span>
        <h3>${escapeHtml(product.name)}</h3>
        <p>${escapeHtml(product.description)}</p>
        <div class="product-bottom"><span class="price">${formatPrice(product.price_cents)}</span><button class="small-button" type="button" data-product="${product.id}">Ver produto</button></div>
      </div>
    </article>`).join('') : '<p class="muted">Nenhum produto encontrado.</p>';
}
function formatPrice(cents) {
  return new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(cents / 100);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
document.querySelector('#menu-toggle')?.addEventListener('click', event => {
  const nav = document.querySelector('.header-actions');
  const opened = nav.classList.toggle('is-open');
  event.currentTarget.setAttribute('aria-expanded', String(opened));
});
document.querySelector('#year') && (document.querySelector('#year').textContent = new Date().getFullYear());
loadProducts();

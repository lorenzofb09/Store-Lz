const subscriptionGrid = document.querySelector('#subscription-grid');
const filters = document.querySelector('#subscription-filters');
async function loadSubscriptions() {
  try {
    const response = await fetch('/api/products?category=assinatura');
    if (!response.ok) throw new Error('Erro ao carregar assinaturas.');
    const products = await response.json();
    draw(products);
    filters.addEventListener('click', event => {
      const button = event.target.closest('[data-filter]');
      if (!button) return;
      filters.querySelectorAll('button').forEach(item => item.classList.remove('is-active'));
      button.classList.add('is-active');
      const type = button.dataset.filter;
      draw(type === 'todos' ? products : products.filter(item => item.segment === type));
    });
  } catch (error) { subscriptionGrid.innerHTML = `<p class="muted">${error.message}</p>`; }
}
function draw(items) {
  subscriptionGrid.innerHTML = items.length ? items.map(item => `<article class="product-card"><div class="product-art">${safe(item.symbol || '◈')}</div><div class="product-info"><span class="product-type">Assinatura</span><h3>${safe(item.name)}</h3><p>${safe(item.description)}</p><div class="product-bottom"><span class="price">${new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(item.price_cents/100)}</span><button class="small-button" type="button">Ver detalhes</button></div></div></article>`).join('') : '<p class="muted">Nenhuma assinatura encontrada.</p>';
}
function safe(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
document.querySelector('#year') && (document.querySelector('#year').textContent = new Date().getFullYear());
loadSubscriptions();

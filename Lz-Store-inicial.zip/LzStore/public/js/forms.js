for (const id of ['login-form','register-form']) {
  const form = document.getElementById(id);
  form?.addEventListener('submit', event => {
    event.preventDefault();
    const message = document.getElementById('form-message');
    message.textContent = 'Formulário visual pronto. A autenticação segura será implementada na próxima etapa.';
  });
}
